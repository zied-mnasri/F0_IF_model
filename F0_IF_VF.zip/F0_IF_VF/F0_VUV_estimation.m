wavefile='mic_M01_sa1_babble20.wav'
[s,fs]=audioread(wavefile);
time=(0:length(s)-1)*1000/fs; %time in msec
[path,name,ext]=fileparts(wavefile);
filename=name;

% Default parameters
f0min=80; %80(Male) 120(Female)
f0max=270; %270(Male) 400 (Female)
f0step=0.1;% sweeping step of f0 candidates (from f0min to f0max)
framedur=32;% in ms
timestep=10;%in ms
smoothing_filter=1;%1: median smoothing, 2: linear smoothing
smoothing_dur=1;% smoothing period in ms
%selection='max';%'max' or 'median' or 'min' (value to select from the kept f0 candidates)
 
%%% Default thresholds
vuv_frame_coef=0.9; %Ratio of unvoiced points in a frame to take VUV decision
threshold2=5;%diff between fi_inst(k) and the highest multiple of F0_cand(k)
threshold3=10;%threshold to decide whether a kept f0 cand is a multiple of another one
threshold1=1500; %for clean speech (For noisy speech with unknown SNR, better use threshold1=mean(dfi_value) in F0_IF_VF.m file)

%%% VUV and F0 estiamtion 
[f0_est_time,f0_est_filt,f0_est_vuv,f0_cand_min_fin]=F0_IF_VF(s,fs,f0min,f0max,framedur,timestep,f0step,vuv_frame_coef,threshold1,threshold2,threshold3,smoothing_dur,smoothing_filter);

%%%%%%%%%% Exporting (f0_time,f0_value) in text file%%%%%%%%%%%%%%%%
f0_est_data=[f0_est_time;f0_est_filt'];
f0_file=strcat(filename,'_f0_est.txt');
fileID = fopen(f0_file,'w');
fprintf(fileID,'%12s %12s \r\n','f0 time(ms)','f0 value(Hz)');
fprintf(fileID,'%12.3f %12.3f\r\n',f0_est_data);
fclose(fileID);

%%%%%%%%%%Draw F0 contour  %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(211)
plot(time,s)
title('speech signal')
subplot(212)
plot(f0_est_time,f0_est_filt)
xlabel('time (msec)')
ylabel('F0 (Hz)')
title('F0 contour extracted from instantaneous frequency')




