function [inst_freq,inst_amp]=HT_fi(x,Fs)
% performing the HILBERT TRANSFORM
hx = hilbert(x);
% calculating the INSTANTANEOUS AMPLITUDE (ENVELOPE)
inst_amp = abs(hx);
% calculating the INSTANTANEOUS FREQUENCY
inst_freq = diff(unwrap(angle(hx)))/((1/Fs)*2*pi);
