function [fi_time,fi_value,ai_value]=fi_extract(s,fs)
[fi_value,ai_value]=HT_fi(s,fs);
fi_time=((0:(length(fi_value)-1))/fs)*1000;
fi_time=fi_time';