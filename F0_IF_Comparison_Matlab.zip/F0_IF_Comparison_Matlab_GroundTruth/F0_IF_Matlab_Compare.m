clear all
close all
wavefile='mic_M01_sa1.wav'; %'mic_F01_sa1.wav' for female voice sample
[s,fs]=audioread(wavefile);
time=(0:length(s)-1)*1000/fs; %time in msec
[path,name,ext]=fileparts(wavefile);
filename=name;

% Default parameters for all benchmarking methods

%f0 boundaries
%for male voice
f0min = 80;
f0max = 270; 
%for female voice
Female=(name(5)=='F');
if (Female)
    f0min = 120;
    f0max = 400;
end 

f0step=0.05;% sweeping step of f0 candidates (from f0min to f0max)
framedur=25;% in ms
timestep=10;%in ms
smoothing_filter=1;%1: median smoothing, 2: linear smoothing
smoothing_dur=0.5;% smoothing period in ms

%%%%%%%% Import reference F0 (Ground truth) %%%%%%%%%%%%%%%
ref_filename=strcat('ref',filename(4:end),'.f0');
f0_ref=importdata(ref_filename);
f0_ref_value=f0_ref(:,1);
f0_ref_vuv=(f0_ref_value>=f0min)&(f0_ref_value<=f0max);
f0_ref_value=f0_ref_value.*f0_ref_vuv;
f0_ref_time=(0:length(f0_ref_value)-1)*timestep;
 
%%%%%%%% Estimate f0 by the proposed method (F0_IF)
%%% Default thresholds
vuv_frame_coef=0.9; %Ratio of unvoiced points in a frame to take VUV decision
threshold1=1000; %for clean speech (For noisy speech with unknown SNR,
                % better use threshold1=mean(dfi_value) in F0_IF_VF.m file)
if (Female), threshold1=1500; end
threshold2=10;%diff between fi_inst(k) and the highest multiple of F0_cand(k)
threshold3=10;%threshold to decide whether a kept f0 cand is a multiple of another one

%%%%%%% VUV and F0 estiamtion %%%%%%%%%%%%%
[f0_est_time,f0_est_filt,f0_est_vuv,f0_cand_min_fin]=F0_IF_VF(s,fs,f0min,...
    f0max,framedur,timestep,f0step,vuv_frame_coef,threshold1,threshold2,threshold3,...
    smoothing_dur,smoothing_filter);

%%%%%%%%%% Exporting extracted(f0_time,f0_value) in text file%%%%%%%%%%%%%%%%
f0_est_data=[f0_est_time;f0_est_filt'];
f0_file=strcat(filename,'_f0_est.txt');
fileID = fopen(f0_file,'w');
fprintf(fileID,'%12s %12s \r\n','f0 time(ms)','f0 value(Hz)');
fprintf(fileID,'%12.3f %12.3f\r\n',f0_est_data);
fclose(fileID);

%%%%%%%%%% Draw F0 contour %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(311)
plot(time,s)
title('speech signal (Male voice)')
subplot(312)
plot(f0_est_time,f0_est_filt)
hold on
plot(f0_ref_time,f0_ref_value)
xlabel('time (msec)')
ylabel('F0 (Hz)')
title('F0 contour extracted from instantaneous frequency')
legend('f0 est by IF','Gnd truth f0')

%% Comparison with Matlab'2020 built-infunction (pitch) (Method: SRH (Drugman 2011)%%%%
[f0_matlab_value,idx] = pitch(s,fs, ...
            'Method','SRH', ...
            'WindowLength',framedur*fs/1000, ...
            'OverlapLength',timestep*fs/1000, ...
            'Range',[f0min,f0max], ...
            'MedianFilterLength',smoothing_dur*fs/1000);
hr = harmonicRatio(s,fs,"Window",hamming(framedur*fs/1000,'periodic'),...
    "OverlapLength",timestep*fs/1000);
hr_threshold=0.4;
f0_matlab_value(hr<hr_threshold)=0;

%%%%%%%% Draw extracted f0 %%%%%%%%%%%%%%%%%%
subplot(3,1,3)
f0_matlab_time = 1000*(idx - 1)/fs;
vuv_matlab=(hr<hr_threshold);
plot(f0_matlab_time,f0_matlab_value)
hold on
plot(f0_ref_time,f0_ref_value)
xlabel('Time (s)')
ylabel('Pitch (Hz)')
legend('F0 est by Matlab','Gnd truth f0')
title('F0 contour extracted from Matlab built-in function (pitch)')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wavefile='mic_F01_sa1.wav'; %'mic_F01_sa1.wav' for female voice sample
[s,fs]=audioread(wavefile);
time=(0:length(s)-1)*1000/fs; %time in msec
[path,name,ext]=fileparts(wavefile);
filename=name;

% Default parameters for all benchmarking methods

%f0 boundaries
%for male voice
f0min = 80;
f0max = 270; 
%for female voice
Female=(name(5)=='F');
if (Female)
    f0min = 120;
    f0max = 400;
end 

f0step=0.05;% sweeping step of f0 candidates (from f0min to f0max)
framedur=25;% in ms
timestep=10;%in ms
smoothing_filter=1;%1: median smoothing, 2: linear smoothing
smoothing_dur=0.5;% smoothing period in ms

%%%%%%%% Import reference F0 (Ground truth) %%%%%%%%%%%%%%%
ref_filename=strcat('ref',filename(4:end),'.f0');
f0_ref=importdata(ref_filename);
f0_ref_value=f0_ref(:,1);
f0_ref_vuv=(f0_ref_value>=f0min)&(f0_ref_value<=f0max);
f0_ref_value=f0_ref_value.*f0_ref_vuv;
f0_ref_time=(0:length(f0_ref_value)-1)*timestep;
 
%%%%%%%% Estimate f0 by the proposed method (F0_IF)
%%% Default thresholds
vuv_frame_coef=0.9; %Ratio of unvoiced points in a frame to take VUV decision
threshold1=1000; %for clean speech (For noisy speech with unknown SNR,
                % better use threshold1=mean(dfi_value) in F0_IF_VF.m file)
if (Female), threshold1=1500; end
threshold2=10;%diff between fi_inst(k) and the highest multiple of F0_cand(k)
threshold3=10;%threshold to decide whether a kept f0 cand is a multiple of another one

%%%%%%% VUV and F0 estiamtion %%%%%%%%%%%%%
[f0_est_time,f0_est_filt,f0_est_vuv,f0_cand_min_fin]=F0_IF_VF(s,fs,f0min,...
    f0max,framedur,timestep,f0step,vuv_frame_coef,threshold1,threshold2,threshold3,...
    smoothing_dur,smoothing_filter);

%%%%%%%%%% Exporting extracted(f0_time,f0_value) in text file%%%%%%%%%%%%%%%%
f0_est_data=[f0_est_time;f0_est_filt'];
f0_file=strcat(filename,'_f0_est.txt');
fileID = fopen(f0_file,'w');
fprintf(fileID,'%12s %12s \r\n','f0 time(ms)','f0 value(Hz)');
fprintf(fileID,'%12.3f %12.3f\r\n',f0_est_data);
fclose(fileID);

%%%%%%%%%% Draw F0 contour %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(311)
plot(time,s)
title('speech signal (Female voice)')
subplot(312)
plot(f0_est_time,f0_est_filt)
hold on
plot(f0_ref_time,f0_ref_value)
xlabel('time (msec)')
ylabel('F0 (Hz)')
title('F0 contour extracted from instantaneous frequency')
legend('f0 est by IF','Gnd truth f0')

%% Comparison with Matlab'2020 built-infunction (pitch) (Method: SRH (Drugman 2011)%%%%
[f0_matlab_value,idx] = pitch(s,fs, ...
            'Method','SRH', ...
            'WindowLength',framedur*fs/1000, ...
            'OverlapLength',timestep*fs/1000, ...
            'Range',[f0min,f0max], ...
            'MedianFilterLength',smoothing_dur*fs/1000);
hr = harmonicRatio(s,fs,"Window",hamming(framedur*fs/1000,'periodic'),...
    "OverlapLength",timestep*fs/1000);
hr_threshold=0.4;
f0_matlab_value(hr<hr_threshold)=0;

%%%%%%%% Draw extracted f0 %%%%%%%%%%%%%%%%%%
subplot(3,1,3)
f0_matlab_time = 1000*(idx - 1)/fs;
vuv_matlab=(hr<hr_threshold);
plot(f0_matlab_time,f0_matlab_value)
hold on
plot(f0_ref_time,f0_ref_value)
xlabel('Time (s)')
ylabel('Pitch (Hz)')
legend('F0 est by Matlab','Gnd truth f0')
title('F0 contour extracted from Matlab built-in function (pitch)')
