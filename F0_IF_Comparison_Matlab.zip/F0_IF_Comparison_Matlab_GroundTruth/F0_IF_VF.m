
function [f0_est_time,f0_est_filt,f0_est_vuv,f0_cand_min_fin]=F0_IF_VF(s,fs,f0min,f0max,framedur,timestep,f0step,vuv_frame_coef,threshold1,threshold2,threshold3,smoothing_dur,smoothing_filter)
%%%%%%%%%%% Default parameters
% f0min=120; %(Male) 120(Female)
% f0max=400 %(Male) 400 (Female)
% f0step=0.1;% sweeping step of f0 candidates (from f0min to f0max)
% framedur=32;% in ms
% timestep=10;%in ms
% smoothing_filter=0;%0: median smoothing, 'lin': linear smoothing
% smooth_period=1;% smoothing period in ms

  
%%%%%%%%%%% Default thresholds
% vuv_frame_coef=0.9;     %(or any value between 0.85 and 0.95) Ratio of 
%                          unvoiced points in a frame to take VUV decision

% threshold1=1500;        %for clean speech (For noisy speech with unknown
%                          SNR, better replace
%                          threshold1=mean(dfi_value) 
%                          in this file (line46))

% threshold2=1;           %difference between fi_inst(k) and the highest
%                          multiple of F0_cand(k)

% threshold3=10;          %Maximum of mod(f0_cand2/f0_cand1) to decide
%                          whether f0_cand2 is nearly a multiple of f0_cand1




[fi_time,fi_value,ai_value]=fi_extract(s,fs);
fi_value=abs(fi_value);

framelength=framedur*fs/1000;
shift=timestep*fs/1000;
frameNb=floor((length(fi_time)-framelength)/shift);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%VUV decision based on dfi thresholding%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
display('Start VUV decision estimation')
dfi_value(1)=fi_value(1);
for k=2:length(fi_time)-1
    dfi_value(k)=abs(fi_value(k+1)-fi_value(k-1))/2;
end
dfi_value(length(fi_time))=dfi_value(length(dfi_value));
%threshold1=mean(dfi_value) %Only for noisy speech !!!

for k=1:frameNb
    
    dfi_value_frame=dfi_value((k-1)*shift+1:(k-1)*shift+framelength);
    
    for h=1:framelength
    if abs(dfi_value_frame(h))>threshold1
        vuv_fi_frame(h)=0;
    else
        vuv_fi_frame(h)=1;
    end
    end
    
    if sum(vuv_fi_frame)>vuv_frame_coef*framelength
        f0_est_vuv(k)=1;
    else
        f0_est_vuv(k)=0;
        
    end
    f0_est_time(k)=fi_time((k-1)*shift+1);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% F0 estimation from IF %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
display('start F0 estimation')

f0_cand=f0min:f0step:f0max;

for k=1:frameNb
    fi_value_max(k)=fi_value((k-1)*shift+1);
    fi_time_max(k)=fi_time((k-1)*shift+1);
    for n=1:length(f0_cand)
        Nh(k,n)=floor(fi_value_max(k)/f0_cand(n));
             fir_cand(k,n)=fi_value_max(k)-Nh(k,n)*f0_cand(n);
    end
end



for j=1:length(fi_value_max)
    f0_err=abs(f0_cand-fir_cand(j,:));
    f0_cand_min=[];
    
    for h=1:length(f0_cand)
           if (f0_err(h)<threshold2)            
               f0_cand_min=[f0_cand_min;fir_cand(j,h)];
          end
    end
    
    if isempty(f0_cand_min)      
       f0_est_val(j)=0;
    else
        if length(f0_cand_min)==1
            f0_est_val(j)=f0_cand_min;
        else
                
                for  h=1:length(f0_cand_min)
                 for m=h+1:length(f0_cand_min)
                
                    if mod(f0_cand_min(m),f0_cand_min(h))<threshold3
                        f0_cand_min(m)=0;               
                    end
                
                 end
                end
                
                f0_cand_min2=[];
                for h=1:length(f0_cand_min)
                    if f0_cand_min(h)>0
                        f0_cand_min2=[f0_cand_min2;f0_cand_min(h)];
                    end
                end
                f0_cand_min_fin{j}=f0_cand_min2;
                
                f0_cand_min2_err=[];
                for m=1:length(f0_cand_min2)
                f0_cand_min2_err(m)=mod(fi_value_max(j),f0_cand_min2(m));
                end
                [~,idx]=min(f0_cand_min2_err);
                f0_est_val(j)=f0_cand_min2(idx);
                
  end
 end
end

f0_est_time=fi_time_max;
if smoothing_dur==0
    f0_est_filt=f0_est_val';
else
    if smoothing_filter==1
        f0_est_filt=medsmooth(f0_est_val,ceil(smoothing_dur*fs/1000));
    elseif smoothing_filter==2
        f0_est_filt=linsmooth(f0_est_val,ceil(smoothing_dur*fs/1000),'hann');
    else
    error('Specify smoothing filter!')
    end
end

f0_est_filt=f0_est_filt.*f0_est_vuv';




